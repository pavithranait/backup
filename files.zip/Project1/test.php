<html>
 <head>
  <title>PHP-Test</title>
 </head>
 <body>
  <?php echo '<p>Hello World</p>'; ?>
  <script type="text/javascript" src="demo_db_connection.js"></script>
  <script src="https://requirejs.org/docs/release/2.3.5/minified/require.js"></script>
 </body>
</html>